Debugging-jQuery
================

Clone this and correct the jQuery errors!
