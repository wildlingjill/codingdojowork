"""
    Sample Controller File

    A Controller should be in charge of responding to a request.
    Load models to interact with the database and load views to render them to the client.

    Create a controller using this template
"""
from system.core.controller import *
import datetime
import random 

def activityFeed():
    if 'activities' not in session:
        session['activities'] = []
    return session['activities']

def sumGold():
    if 'gold' not in session:
        session['gold'] = 0
    return session['gold']


class Ninjas(Controller):
    def __init__(self, action):
        super(Ninjas, self).__init__(action)
        """
            This is an example of loading a model.
            Every controller has access to the load_model method.
        """
        self.load_model('WelcomeModel')
        self.db = self._app.db

        """
        
        This is an example of a controller method that will load a view for the client 

        """
   
    def index(self):
        """
        A loaded model is accessible through the models attribute 
        self.models['WelcomeModel'].get_users()
        
        self.models['WelcomeModel'].add_message()
        # messages = self.models['WelcomeModel'].grab_messages()
        # user = self.models['WelcomeModel'].get_user()
        # to pass information on to a view it's the same as it was with Flask
        
        # return self.load_view('index.html', messages=messages, user=user)
        """
        activityFeed()
        sumGold()
        return self.load_view('index.html', activities=session['activities'])


    def processMoney(self):
        if request.form["building"] == "farm":
            random_number = random.randrange(10, 21)
            session['gold'] += random_number
            session['activities'].append('Earned %d gold from the farm!' % (random_number))
            print session['activities'][-1]
            return redirect('/')
        elif request.form["building"] == "cave":
            random_number = random.randrange(5, 11)
            session['gold'] += random_number
            session['activities'].append('Earned %d gold from the cave!' % (random_number))
            print session['activities'][-1]
            return redirect('/')
        elif request.form["building"] == "house":
            random_number = random.randrange(2, 6)
            session['gold'] += random_number
            session['activities'].append('Earned %d gold from the house!' % (random_number))
            print session['activities'][-1]
            return redirect('/')
        else:
            random_number = random.randrange(-50, 51)
            session['gold'] += random_number
            if (random_number > 0):
                session['activities'].append('Earned %d gold from the casino!' % (random_number))
            else:
                session['activities'].append('Entered a casino and lost %d gold...Ouch.' % (random_number * -1))
            print session['activities'][-1]
            return redirect('/')



    def resetGold(self):
        session['gold'] = 0
        session['activities'][:] = []
        return redirect('/')

