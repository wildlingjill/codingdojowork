select * from emails;
INSERT INTO emails (email_address, created_at, updated_at) 
VALUES ('email@codingdojo,com', NOW(), NOW());